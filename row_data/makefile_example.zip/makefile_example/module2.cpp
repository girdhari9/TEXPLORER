#include"module2.h"

void someRandomFunc(){
	std::cout<<"hello, I do nothing!"<<std::endl;
}
