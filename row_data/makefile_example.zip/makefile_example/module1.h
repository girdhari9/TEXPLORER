#include<iostream>

#ifndef INC_MODULE1_H
#define INC_MODULE1_H

void printDummyVar();
int getDummyVar();
void setDummyVar(int);

#endif  /*INC_MODULE1_H*/

