#include<iostream>
#include<stdlib.h>

#ifndef INC_MODULE2_H
#define INC_MODULE2_H

void someRandomFunc();

#endif	/*INC_MODULE2_H*/
